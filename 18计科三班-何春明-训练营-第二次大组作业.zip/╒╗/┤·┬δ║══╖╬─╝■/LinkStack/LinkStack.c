#include <stdlib.h>
#include "../head/LinkStack.h"
#include <stdio.h> 

//�Զ�������
Status StackTraverse(LinkStack *s) 
{
	if(s->top->next == NULL) 
		return 0;
    LinkStackPtr p;
    p = s->top->next;
    while(p)
	{
        printf("|%d|\n", p->data);
        p = p->next;
    }
    printf("|_|");
    return 1;
}
 


/************************************************************************************************************/
//��ջ(����������)
Status initLStack(LinkStack *s)   //��ʼ��
{
    s->top = (LinkStackPtr)malloc(sizeof(StackNode));		//�Ҽ��˸�ͷ��� 
    s->top->next = NULL; 
    s->count = 0;
	return 1;
}

Status isEmptyLStack(LinkStack *s)  //�ж���ջ�Ƿ�Ϊ��
{ 	
	if( s->top->next == NULL)
		return 1;
	else return 0;
}

Status getTopLStack(LinkStack *s,ElemType *e)  //�õ�ջ��Ԫ��
{
	if( s->top->next == NULL)
		return 0;
	*e = s->top->next->data;
	return 1;
}
		
	

Status clearLStack(LinkStack *s)   //���ջ
{
	if( s->top->next == NULL)
		return 0;
	LinkStackPtr p1 = s->top->next, p2;
	while(p1)
	{
		p2 = p1->next;
		free(p1);
		p1 = p2;
		--s->count;
	}
	return 1; 
} 
	


Status destroyLStack(LinkStack *s)   //����ջ
{	
	clearLStack(s);		//�����ջ 
	free(s->top);		//��freeͷ��� 
	s->top = NULL;
	return 1;
}

Status LStackLength(LinkStack *s,int *length)    //���ջ����
{
	if( s->top->next == NULL)
		return 0;
	*length = s->count;
	return 1; 
}

Status pushLStack(LinkStack *s,ElemType data)   //��ջ
{
	LinkStackPtr p ;	
	p = (LinkStackPtr)malloc(sizeof(StackNode));
    p->data = data;
    p->next = s->top->next;
    s->top->next = p;
    ++s->count;
}	

Status popLStack(LinkStack *s,ElemType *data)   //��ջ
{
	
	if( s->top->next == NULL)
		return 0;
	
	LinkStackPtr p = s->top->next;	//p��¼ͷ���ֱ�Ӻ�̽�� 
	
	*data = p->data;
	s->top->next = p->next;
	free(p);
	--s->count;
	return 1;
} 
	
	
	
	
