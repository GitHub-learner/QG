#include "../ͷ�ļ�/LQueue.h"  
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void InitLQueue(LQueue *Q)
{
	Node *p = (Node*)malloc(sizeof(Node));
	if(NULL == p)
		return;			//����Ƿ�����ڴ�ɹ�
	p->next = NULL;
	Q->front = Q->rear = p; //ͷ��� 
}


Status IsEmptyLQueue(const LQueue *Q)
{
	return Q->front == Q->rear;	
}

/*Status GetHeadLQueue(LQueue *Q, void *e)
{
	if(IsEmptyLQueue(Q) == 1)	
		return 0;
	//memcpy( e, Q->data[(Q->front+1)&MAXQUEUE], Q->size[Q->front]);		//��Ϊ��ѡ���������ָ����ȡ��Ԫ�� 
	return 1;	
}*/////////////////////////////////////////////////	û��Ҫ�ú����õ���ͷ��ֱ��LPrint���� 

int LengthLQueue(LQueue *Q)
{	
	int count = 0;
	Node *p = Q->front;
	while( p != Q->rear)
	{
		++count;
		p = p->next;
	}
	return count + 1;
}

Status EnLQueue(LQueue *Q, void *data, int size)
{
	Node *p = (Node *)malloc(sizeof(Node));
	p->next = NULL; 
	if(NULL == p)
		return;			//����Ƿ�����ڴ�ɹ�								
	p->data = data; 
	p->size = size;
	Q->rear->next = p;
	Q->rear = p;
	//memcpy( Q->data[Q->rear], data,size );  	//��ѧ��<string.h>�ĺ��� 
	return 1;
}

Status DeLQueue(LQueue *Q)	// 
{
	if(IsEmptyLQueue(Q) == 1)	
		return 0;
	Node *p = Q->front->next;	//p��¼ͷ���ֱ�Ӻ�̽�� 
	Q->front->next = p->next;
	free(p);
	if(NULL == Q->front->next)
		Q->rear = Q->front; 
	return 1;
}

void ClearLQueue(LQueue *Q)
{
	Node *p1, *p2;
	p1 = Q->front->next;
	while(p1)
	{
				 
		p2 = p1->next;		//p2��¼p1ֱ�Ӻ�̽��
		free(p1); 
		p1 = p2;
	}
	Q->rear = Q->front;
	Q->front->next = NULL;
}

void DestoryLQUEUE(LQueue *Q)
{
	ClearLQueue(Q);
	free(Q->front);
	Q->front->next = NULL;
}

Status TraverseLQueue(const LQueue *Q, void (*foo)(void *q, int size))
{
	if(IsEmptyLQueue(Q) == 1)	
		return 0;
	Node *p = Q->front->next;
	while(p)
	{
		(*foo)(p->data, p->size );
		p = p->next;									
		printf("-<");											 
	}
	return 1;
}

//�����ֽ�����ʵ�ֱ���
void LPrint(void *q, int size)
{
	if (size == sizeof(double))		
		printf("%lf", *(double *)q);	
	
	else if (size == sizeof(char))		
		printf("%c", *(char *)q);	
	
	else if (size == sizeof (int))		
		printf("%d", *(int *)q);
	
	else	puts(q);
}	
			
