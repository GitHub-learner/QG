#include "../ͷ�ļ�/AQueue.h"  
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void InitAQueue(PAQueue *Q)
{
	*Q = (PAQueue)malloc( sizeof(struct AQueue) ); 
	(*Q)->front = (*Q)->rear = 0;

}

void DestoryAQUEUE(PAQueue *Q)
{
	free(*Q);
	*Q = NULL; 
}

Status IsFullAQueue(const PAQueue Q)
{
	return Q->front == (Q->rear + 1) % MAXQUEUE ;		//
} 

Status IsEmptyAQueue(const PAQueue Q)
{
	return Q->front == Q->rear;	
}

Status GetHeadAQueue(PAQueue Q, void *e)
{
	if(IsEmptyAQueue(Q) == 1)	
		return 0;
	e = Q->data[(Q->front+1)%MAXQUEUE];
	//memcpy( e, Q->data[(Q->front+1)&MAXQUEUE], Q->size[Q->front]);		//��Ϊ��ѡ���������ָ����ȡ��Ԫ�� 
	return 1;	
}

int LengthAQueue(PAQueue Q)
{
	return ( Q->rear - Q->front + MAXQUEUE) % MAXQUEUE;
}

Status EnAQueue(PAQueue Q, void *data, int size)
{
	if(IsFullAQueue(Q) == 1)	
		return 0;
	Q->rear = ( Q->rear +1 ) % MAXQUEUE;		//��ѡ��������ƶ�ָ������� 
	Q->data[Q->rear] = data; 
	Q->size[Q->rear] = size;
	//memcpy( Q->data[Q->rear], data,size );  	//��ѧ��<string.h>�ĺ��� 
	return 1;
}

Status DeAQueue(PAQueue Q)		// 
{
	if(IsEmptyAQueue(Q) == 1)	
		return 0;
	Q->front = (Q->front + 1) % MAXQUEUE;
	return 1;
}

void ClearAQueue(PAQueue Q)
{
	Q->front = Q->rear = 0;
}

Status TraverseAQueue(const PAQueue Q, void (*foo)(void *q, int size))
{
	if(IsEmptyAQueue(Q) == 1)	
		return 0;
	int i;
	for(i = (Q->front + 1) % MAXQUEUE; i-1 != Q->rear; i = (i + 1) % MAXQUEUE )		//��Ϊ��ѡ��������ƶ�ָ������� 
	{																				//����i==Q->rearʱ����Ҫִ��ѭ�� 
		(*foo)(Q->data[i], Q->size[i]);												//��ΪQ->data[Q->reaer]Ҳ��Ԫ�� 
		printf("-<");
	}
	return 1;
}

void APrint(void *q, int size)
{
	if (size == sizeof(double))		
		printf("%lf", *(double *)q);	
	
	else if (size == sizeof(char))		
		printf("%c", *(char *)q);	
	
	else if (size == sizeof (int))		
		printf("%d", *(int *)q);
	
	else	puts(q);
}	
			
